import { useEffect, useMemo, useState } from 'react'
import './App.css'

function createLineItem(itemCode = '') {
  return {
    id: crypto.randomUUID(),
    itemCode,
    bags: '1',
  }
}

const initialForm = {
  buyerCode: '',
  vehicleNumber: '',
  invoiceDate: new Date().toISOString().slice(0, 10),
  lineItems: [createLineItem()],
}

const maxLineItems = 8

function App() {
  const [buyers, setBuyers] = useState([])
  const [items, setItems] = useState([])
  const [form, setForm] = useState(initialForm)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState(null)

  useEffect(() => {
    async function loadMasters() {
      try {
        const response = await fetch('/api/masters')
        const data = await response.json()
        if (!response.ok) {
          throw new Error(data.error || 'Failed to load master data.')
        }
        setBuyers(data.buyers)
        setItems(data.items)
        setForm((current) => ({
          ...current,
          buyerCode: data.buyers[0]?.Buyer_Code || '',
          lineItems: [createLineItem(data.items[0]?.Item_Code || '')],
        }))
      } catch (loadError) {
        setError(loadError.message)
      } finally {
        setLoading(false)
      }
    }

    loadMasters()
  }, [])

  const selectedBuyer = useMemo(
    () => buyers.find((buyer) => buyer.Buyer_Code === form.buyerCode),
    [buyers, form.buyerCode],
  )

  const computedLines = useMemo(
    () =>
      form.lineItems.map((line) => {
        const selectedItem = items.find((item) => item.Item_Code === line.itemCode)
        const bags = Number(line.bags || 0)
        const bottlesPerBag = Number(selectedItem?.Bottles_Per_Bag || 0)
        const quantity = bags * bottlesPerBag
        const grossRate = Number(selectedItem?.Gross_Rate || 0)
        const nonTaxableRate = Number(selectedItem?.Non_Taxable_Rate || 0)
        const taxableRate = grossRate - nonTaxableRate
        const amount = quantity * grossRate
        const nonTaxableValue = quantity * nonTaxableRate
        const taxableValue = quantity * taxableRate

        return {
          ...line,
          selectedItem,
          bags,
          bottlesPerBag,
          quantity,
          grossRate,
          amount,
          nonTaxableRate,
          nonTaxableValue,
          taxableRate,
          taxableValue,
        }
      }),
    [form.lineItems, items],
  )

  const computedTotals = useMemo(() => {
    const quantity = computedLines.reduce((sum, line) => sum + line.quantity, 0)
    const taxableValue = computedLines.reduce((sum, line) => sum + line.taxableValue, 0)
    const nonTaxableValue = computedLines.reduce((sum, line) => sum + line.nonTaxableValue, 0)
    const cgst = taxableValue * 0.09
    const sgst = taxableValue * 0.09
    const total = nonTaxableValue + taxableValue + cgst + sgst

    return {
      quantity,
      taxableValue,
      nonTaxableValue,
      cgst,
      sgst,
      total,
    }
  }, [computedLines])

  async function handleSubmit(event) {
    event.preventDefault()
    setSubmitting(true)
    setError('')

    try {
      const response = await fetch('/api/invoices/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(form),
      })
      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate invoice.')
      }
      setResult(data)
    } catch (submitError) {
      setError(submitError.message)
    } finally {
      setSubmitting(false)
    }
  }

  function updateField(event) {
    const { name, value } = event.target
    setForm((current) => ({
      ...current,
      [name]: value,
    }))
  }

  function updateLineItem(id, field, value) {
    setForm((current) => ({
      ...current,
      lineItems: current.lineItems.map((line) =>
        line.id === id
          ? {
              ...line,
              [field]: value,
            }
          : line,
      ),
    }))
  }

  function addLineItem() {
    if (form.lineItems.length >= maxLineItems) {
      setError(`This template supports up to ${maxLineItems} item rows per invoice.`)
      return
    }

    setForm((current) => ({
      ...current,
      lineItems: [...current.lineItems, createLineItem(items[0]?.Item_Code || '')],
    }))
  }

  function removeLineItem(id) {
    setForm((current) => {
      if (current.lineItems.length === 1) {
        return current
      }

      return {
        ...current,
        lineItems: current.lineItems.filter((line) => line.id !== id),
      }
    })
  }

  if (loading) {
    return <main className="app-shell app-shell-loading"><p className="status-card">Loading master data...</p></main>
  }

  return (
    <main className="app-shell">
      <section className="hero">
        <div>
          <p className="eyebrow">Yash Bottles</p>
          <h1>Invoice generator for your buyer, item, and quantity workflow.</h1>
          <p className="hero-copy">
            Select the buyer, vehicle number, item, and bags. The app calculates quantity,
            fills the invoice, and generates both Excel and PDF downloads.
          </p>
          <div className="hero-metrics">
            <div>
              <span>Total Number Of Items</span>
              <strong>{form.lineItems.length}</strong>
            </div>
            <div>
              <span>Total Qty</span>
              <strong>{computedTotals.quantity || 0}</strong>
            </div>
            <div>
              <span>Current Total</span>
              <strong>{formatMoney(computedTotals.total)}</strong>
            </div>
          </div>
        </div>
        <div className="hero-badge">
          <span>Template-backed Excel</span>
          <strong>{form.lineItems.length} line items ready</strong>
          <p>PDF + Excel stay in sync from the same invoice data.</p>
          <div className="hero-badge-grid">
            <div>
              <small>Rows Supported</small>
              <b>Up to 8</b>
            </div>
            <div>
              <small>HSN Code</small>
              <b>7010</b>
            </div>
          </div>
        </div>
      </section>

      <section className="content-grid">
        <form className="panel form-panel" onSubmit={handleSubmit}>
          <div className="panel-header">
            <h2>Invoice details</h2>
            <p>Source data comes from the CSV files in this folder.</p>
          </div>

          <div className="top-fields">
            <label className="field-span-2">
              <span>Buyer name</span>
              <select name="buyerCode" value={form.buyerCode} onChange={updateField}>
                {buyers.map((buyer) => (
                  <option key={buyer.Buyer_Code} value={buyer.Buyer_Code}>
                    {buyer.Buyer_Name}
                  </option>
                ))}
              </select>
            </label>

            <label>
              <span>Vehicle number</span>
              <input
                name="vehicleNumber"
                value={form.vehicleNumber}
                onChange={updateField}
                placeholder="MH12AB1234"
              />
            </label>

            <label>
              <span>Invoice date</span>
              <input name="invoiceDate" type="date" value={form.invoiceDate} onChange={updateField} />
            </label>
          </div>

          <div className="line-items-section">
            <div className="line-items-header">
              <div>
                <span className="section-label">Invoice items</span>
                <p>Add as many item rows as you need.</p>
              </div>
              <button className="secondary-button" type="button" onClick={addLineItem}>
                Add item
              </button>
            </div>

            <p className="hint-text">Current Excel template supports up to {maxLineItems} item rows.</p>

            <div className="line-items-list">
              {computedLines.map((line, index) => (
                <article className="line-item-card" key={line.id}>
                  <div className="line-item-topbar">
                    <strong>Item {index + 1}</strong>
                    <button
                      className="text-button"
                      type="button"
                      onClick={() => removeLineItem(line.id)}
                      disabled={form.lineItems.length === 1}
                    >
                      Remove
                    </button>
                  </div>
                  <div className="line-item-layout">
                    <div className="line-item-fields">
                      <label>
                        <span>Description of item</span>
                        <select
                          value={line.itemCode}
                          onChange={(event) => updateLineItem(line.id, 'itemCode', event.target.value)}
                        >
                          {items.map((item) => (
                            <option key={item.Item_Code} value={item.Item_Code}>
                              {item.Description}
                            </option>
                          ))}
                        </select>
                      </label>

                      <label>
                        <span>Number of bags</span>
                        <input
                          type="number"
                          min="1"
                          value={line.bags}
                          onChange={(event) => updateLineItem(line.id, 'bags', event.target.value)}
                        />
                      </label>
                    </div>

                    <div className="line-item-metrics">
                      <div className="metric-card">
                        <span className="metric-label">Qty</span>
                        <strong className="metric-value">{line.quantity || 0}</strong>
                        <small className="metric-note">{line.bags || 0} x {line.bottlesPerBag || 0}</small>
                      </div>
                      <div className="metric-card">
                        <span className="metric-label">Gross rate</span>
                        <strong className="metric-value">{formatMoney(line.grossRate)}</strong>
                        <small className="metric-note">Per piece</small>
                      </div>
                      <div className="metric-card">
                        <span className="metric-label">Taxable rate</span>
                        <strong className="metric-value">{formatMoney(line.taxableRate)}</strong>
                        <small className="metric-note">Per piece</small>
                      </div>
                      <div className="metric-card">
                        <span className="metric-label">Line taxable</span>
                        <strong className="metric-value">{formatMoney(line.taxableValue)}</strong>
                        <small className="metric-note">HSN 7010</small>
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>

          <div className="calc-grid">
            <article>
              <span>Qty</span>
              <strong>{computedTotals.quantity || 0}</strong>
              <small>Total across all items</small>
            </article>
            <article>
              <span>Taxable value</span>
              <strong>{formatMoney(computedTotals.taxableValue)}</strong>
              <small>Combined taxable amount</small>
            </article>
            <article>
              <span>Grand total</span>
              <strong>{formatMoney(computedTotals.total)}</strong>
              <small>Including CGST + SGST</small>
            </article>
          </div>

          {error ? <p className="error-banner">{error}</p> : null}

          <button className="primary-button" type="submit" disabled={submitting}>
            {submitting ? 'Generating files...' : 'Generate invoice'}
          </button>
        </form>

        <section className="panel preview-panel">
          <div className="panel-header">
            <h2>Live preview</h2>
            <p>The generated Excel uses your template workbook. The PDF uses the same invoice data.</p>
          </div>

          <div className="invoice-card">
            <header>
              <div>
                <p className="mini-label">Buyer</p>
                <h3>{selectedBuyer?.Buyer_Name || 'Select a buyer'}</h3>
              </div>
              <div>
                <p className="mini-label">Vehicle</p>
                <h3>{form.vehicleNumber || 'Not entered yet'}</h3>
              </div>
            </header>

            <div className="preview-lines">
              {computedLines.map((line, index) => (
                <div className="preview-line" key={line.id}>
                  <div className="preview-line-head">
                    <div>
                      <p className="mini-label">Item {index + 1}</p>
                      <h3>{line.selectedItem ? `${line.selectedItem.Description} (${line.bags || 0} bags)` : '--'}</h3>
                    </div>
                    <div className="preview-chip">HSN 7010</div>
                  </div>
                  <div className="preview-rate-bar">
                    <div>
                      <span>Gross rate</span>
                      <strong>{formatMoney(line.grossRate)}</strong>
                    </div>
                    <div>
                      <span>Taxable rate / piece</span>
                      <strong>{formatMoney(line.taxableRate)}</strong>
                    </div>
                    <div>
                      <span>Amount</span>
                      <strong>{formatMoney(line.amount)}</strong>
                    </div>
                  </div>
                  <dl className="invoice-meta">
                    <div>
                      <dt>Bags</dt>
                      <dd>{line.bags || 0}</dd>
                    </div>
                    <div>
                      <dt>Quantity</dt>
                      <dd>{line.quantity || 0}</dd>
                    </div>
                    <div>
                      <dt>Line total</dt>
                      <dd>{formatMoney(line.amount)}</dd>
                    </div>
                  </dl>
                </div>
              ))}
            </div>

            <div className="totals">
              <div>
                <span>Taxable value</span>
                <strong>{formatMoney(computedTotals.taxableValue)}</strong>
              </div>
              <div>
                <span>Non-taxable</span>
                <strong>{formatMoney(computedTotals.nonTaxableValue)}</strong>
              </div>
              <div>
                <span>CGST 9%</span>
                <strong>{formatMoney(computedTotals.cgst)}</strong>
              </div>
              <div>
                <span>SGST 9%</span>
                <strong>{formatMoney(computedTotals.sgst)}</strong>
              </div>
              <div className="grand-total">
                <span>Total</span>
                <strong>{formatMoney(computedTotals.total)}</strong>
              </div>
            </div>
          </div>

          {result ? (
            <div className="downloads">
              <p>
                Generated invoice <strong>{result.invoice.invoiceNumber}</strong>
              </p>
              <div className="download-actions">
                <a href={result.files.excel} target="_blank" rel="noreferrer">
                  Download Excel
                </a>
                <a href={result.files.pdf} target="_blank" rel="noreferrer">
                  Download PDF
                </a>
              </div>
            </div>
          ) : (
            <p className="hint-text">Generate an invoice to get downloadable Excel and PDF files.</p>
          )}
        </section>
      </section>
    </main>
  )
}

function formatMoney(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(Number(value || 0))
}

export default App
