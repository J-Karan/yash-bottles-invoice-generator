import cors from 'cors'
import ExcelJS from 'exceljs'
import express from 'express'
import fs from 'fs/promises'
import fsSync from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { parse } from 'csv-parse/sync'
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const rootDir = path.resolve(__dirname, '..')
const generatedDir = path.join(rootDir, 'generated')
const distDir = path.join(rootDir, 'dist')
const templatePath = path.join(rootDir, 'Invoice Temp.xlsx')
const buyersPath = path.join(rootDir, 'Buyers_Master.csv')
const itemsPath = path.join(rootDir, 'Items_Master.csv')
const maxLineItems = 8

const app = express()
const port = Number(process.env.PORT || 5000)

app.use(cors())
app.use(express.json())
app.use('/downloads', express.static(generatedDir))

app.get('/api/health', (_req, res) => {
  res.json({ ok: true })
})

app.get('/api/masters', async (_req, res) => {
  try {
    const [buyers, items] = await Promise.all([readCsv(buyersPath), readCsv(itemsPath)])
    res.json({
      buyers,
      items,
    })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

app.post('/api/invoices/generate', async (req, res) => {
  try {
    const invoicePayload = await buildInvoicePayload(req.body)
    await fs.mkdir(generatedDir, { recursive: true })

    const excelFilename = `${invoicePayload.invoiceKey}.xlsx`
    const pdfFilename = `${invoicePayload.invoiceKey}.pdf`
    const excelOutputPath = path.join(generatedDir, excelFilename)
    const pdfOutputPath = path.join(generatedDir, pdfFilename)

    await generateExcelInvoice(invoicePayload, excelOutputPath)
    await generatePdfInvoice(invoicePayload, pdfOutputPath)

    res.json({
      invoice: invoicePayload,
      files: {
        excel: `/downloads/${excelFilename}`,
        pdf: `/downloads/${pdfFilename}`,
      },
    })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

if (fsSync.existsSync(distDir)) {
  app.use(express.static(distDir))

  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api') || req.path.startsWith('/downloads')) {
      next()
      return
    }

    res.sendFile(path.join(distDir, 'index.html'))
  })
}

app.listen(port, async () => {
  await fs.mkdir(generatedDir, { recursive: true })
  console.log(`Invoice server running on http://localhost:${port}`)
})

async function readCsv(filePath) {
  const content = await fs.readFile(filePath, 'utf8')
  return parse(content, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  })
}

async function buildInvoicePayload(input) {
  const buyers = await readCsv(buyersPath)
  const items = await readCsv(itemsPath)

  const buyer = buyers.find((entry) => entry.Buyer_Code === input.buyerCode)
  if (!buyer) {
    throw new Error('Selected buyer was not found.')
  }

  const lineItemsInput = Array.isArray(input.lineItems) ? input.lineItems : []
  if (!lineItemsInput.length) {
    throw new Error('At least one invoice item is required.')
  }
  if (lineItemsInput.length > maxLineItems) {
    throw new Error(`This template supports up to ${maxLineItems} item rows per invoice.`)
  }

  const vehicleNumber = String(input.vehicleNumber || '').trim().toUpperCase()
  if (!vehicleNumber) {
    throw new Error('Vehicle number is required.')
  }

  const invoiceDate = input.invoiceDate || new Date().toISOString().slice(0, 10)
  const lines = lineItemsInput.map((line, index) => {
    const item = items.find((entry) => entry.Item_Code === line.itemCode)
    if (!item) {
      throw new Error(`Selected item was not found for line ${index + 1}.`)
    }

    const bags = Number(line.bags)
    if (!Number.isFinite(bags) || bags <= 0) {
      throw new Error(`Bags must be greater than zero for line ${index + 1}.`)
    }

    const bottlesPerBag = Number(item.Bottles_Per_Bag)
    const quantity = bags * bottlesPerBag
    const grossRate = Number(item.Gross_Rate)
    const nonTaxableRate = Number(item.Non_Taxable_Rate)
    const taxableRate = roundCurrency(grossRate - nonTaxableRate)
    const amount = roundCurrency(quantity * grossRate)
    const nonTaxableValue = roundCurrency(quantity * nonTaxableRate)
    const taxableValue = roundCurrency(quantity * taxableRate)

    return {
      item,
      bags,
      bottlesPerBag,
      quantity,
      grossRate,
      amount,
      nonTaxableRate,
      nonTaxableValue,
      taxableRate,
      taxableValue,
    }
  })

  const quantity = lines.reduce((sum, line) => sum + line.quantity, 0)
  const amount = roundCurrency(lines.reduce((sum, line) => sum + line.amount, 0))
  const nonTaxableValue = roundCurrency(lines.reduce((sum, line) => sum + line.nonTaxableValue, 0))
  const taxableValue = roundCurrency(lines.reduce((sum, line) => sum + line.taxableValue, 0))
  const cgst = roundCurrency(taxableValue * 0.09)
  const sgst = roundCurrency(taxableValue * 0.09)
  const taxableAfterGst = roundCurrency(taxableValue + cgst + sgst)
  const total = roundCurrency(nonTaxableValue + taxableAfterGst)

  const invoiceNumber = await nextInvoiceNumber(invoiceDate)
  const invoiceKey = invoiceNumber.replace('/', '-')

  return {
    invoiceNumber,
    invoiceKey,
    invoiceDate,
    vehicleNumber,
    quantity,
    amount,
    nonTaxableValue,
    taxableValue,
    cgst,
    sgst,
    taxableAfterGst,
    total,
    buyer,
    lines,
  }
}

async function nextInvoiceNumber(invoiceDate) {
  const year = new Date(invoiceDate).getFullYear()
  const suffix = `${year}-${String(year + 1).slice(-2)}`
  const existingFiles = await fs.readdir(generatedDir, { withFileTypes: true }).catch(() => [])
  const existingNumbers = existingFiles
    .filter((entry) => entry.isFile() && entry.name.endsWith('.xlsx'))
    .map((entry) => entry.name.replace('.xlsx', ''))
    .map((entry) => Number(entry.split('-')[0]))
    .filter((entry) => Number.isFinite(entry))

  const nextSerial = (existingNumbers.length ? Math.max(...existingNumbers) : 0) + 1
  return `${String(nextSerial).padStart(3, '0')}/${suffix}`
}

async function generateExcelInvoice(invoice, outputPath) {
  const workbook = new ExcelJS.Workbook()
  await workbook.xlsx.readFile(templatePath)
  const sheet = workbook.getWorksheet('Temp') || workbook.worksheets[0]

  sheet.getCell('J2').value = invoice.invoiceNumber
  sheet.getCell('J3').value = formatDate(invoice.invoiceDate)
  sheet.getCell('J4').value = invoice.vehicleNumber

  sheet.getCell('A7').value = invoice.buyer.Buyer_Name
  sheet.getCell('A8').value = sanitizeLine(invoice.buyer.Address_Line1)
  sheet.getCell('A9').value = sanitizeLine(invoice.buyer.Address_Line2)
  sheet.getCell('A10').value = [invoice.buyer.Address_Line3, invoice.buyer.City_State_Pin].filter(Boolean).join(', ')
  sheet.getCell('A11').value = `GSTIN: ${invoice.buyer.GSTIN}`

  sheet.getCell('I7').value = invoice.buyer.Ship_To_Name || 'SAME As TO'
  sheet.getCell('I8').value = invoice.buyer.Ship_To_Address || 'SAME As TO'
  sheet.getCell('I9').value = ''
  sheet.getCell('I10').value = ''
  sheet.getCell('I11').value = ''

  const firstRow = 13
  const lastTemplateRow = 20

  for (let row = firstRow; row <= lastTemplateRow; row += 1) {
    sheet.getCell(`A${row}`).value = null
    sheet.getCell(`B${row}`).value = null
    sheet.getCell(`C${row}`).value = null
    sheet.getCell(`D${row}`).value = null
    sheet.getCell(`E${row}`).value = null
    sheet.getCell(`G${row}`).value = null
  }

  invoice.lines.forEach((line, index) => {
    const row = firstRow + index
    sheet.getCell(`A${row}`).value = index + 1
    sheet.getCell(`B${row}`).value = line.item.Description
    sheet.getCell(`C${row}`).value = line.item.HSN_Code
    sheet.getCell(`D${row}`).value = line.quantity
    sheet.getCell(`E${row}`).value = line.grossRate
    sheet.getCell(`G${row}`).value = line.nonTaxableRate
  })

  sheet.pageSetup = {
    paperSize: 9,
    orientation: 'portrait',
    fitToPage: true,
    fitToWidth: 1,
    fitToHeight: 1,
    printArea: 'A1:J36',
  }

  applyCurrencyFormatting(sheet, [
    'D21',
    'H21',
    'J21',
    'J23',
    'J24',
    'J25',
    'J26',
    'J27',
    'J28',
  ])

  invoice.lines.forEach((_, index) => {
    const row = firstRow + index
    applyCurrencyFormatting(sheet, [`E${row}`, `F${row}`, `G${row}`, `H${row}`, `I${row}`, `J${row}`])
  })

  workbook.calcProperties.fullCalcOnLoad = true
  workbook.calcProperties.forceFullCalc = true

  await workbook.xlsx.writeFile(outputPath)
}

function applyCurrencyFormatting(sheet, cells) {
  cells.forEach((address) => {
    sheet.getCell(address).numFmt = '#,##0.00'
  })
}

async function generatePdfInvoice(invoice, outputPath) {
  const pdf = await PDFDocument.create()
  const font = await pdf.embedFont(StandardFonts.Helvetica)
  const fontBold = await pdf.embedFont(StandardFonts.HelveticaBold)
  const black = rgb(0.08, 0.08, 0.08)
  const red = rgb(0.64, 0.17, 0.12)
  const pageWidth = 841.89
  const margin = 28
  const contentWidth = pageWidth - margin * 2
  const lineGap = 12
  const headerLeftWidth = 420
  const headerRightWidth = contentWidth - headerLeftWidth - 16
  const companyLines = [
    'YASH BOTTLES',
    'Gat No 54/5, Nr Jambhulwadi Lake, Pune Satara Highway,',
    'Jambhulwadi, Pune-411046',
    'GSTIN : 27BZCPA4008G1ZX',
  ]
  const metaRows = [
    ['Invoice Number', invoice.invoiceNumber],
    ['Date', formatDate(invoice.invoiceDate)],
    ['Vehicle Number', invoice.vehicleNumber],
  ]
  const headerHeight = 78

  const buyerWidth = (contentWidth - 18) / 2
  const buyerLines = [
    invoice.buyer.Buyer_Name,
    sanitizeLine(invoice.buyer.Address_Line1),
    sanitizeLine(invoice.buyer.Address_Line2),
    [invoice.buyer.Address_Line3, invoice.buyer.City_State_Pin].filter(Boolean).join(', '),
    `GSTIN: ${invoice.buyer.GSTIN}`,
  ].filter(Boolean)
  const shipToName = sanitizeLine(invoice.buyer.Ship_To_Name)
  const shipToAddress = sanitizeLine(invoice.buyer.Ship_To_Address)
  const hasDistinctShipTo =
    !!shipToName &&
    shipToName.toUpperCase() !== 'SAME AS TO' &&
    shipToName.toUpperCase() !== invoice.buyer.Buyer_Name.toUpperCase()
  const shipLines = hasDistinctShipTo
    ? [shipToName, shipToAddress].filter(Boolean)
    : []

  const toBoxWidth = hasDistinctShipTo ? buyerWidth : contentWidth
  const shipBoxWidth = buyerWidth
  const buyerWrapped = buyerLines.flatMap((line, index) =>
    wrapText(line, toBoxWidth - 24, index === 0 ? fontBold : font, index === 0 ? 11 : 10),
  )
  const shipWrapped = shipLines.flatMap((line, index) =>
    wrapText(line, shipBoxWidth - 24, index === 0 ? fontBold : font, index === 0 ? 11 : 10),
  )
  const addressHeight = Math.max(buyerWrapped.length, shipWrapped.length || 0) * lineGap + 32

  const colWidths = [36, 180, 55, 48, 72, 72, 78, 82, 82, 80]
  const headers = [
    'Sr No',
    'Description Of Goods',
    'HSN CODE',
    'Qty',
    'Gross Rate (Rs)',
    'Amount (Rs)',
    'Non Taxable Rate (Rs)',
    'Non Taxable Value (Rs)',
    'Taxable Rate (Rs) Per Piece',
    'Taxable Value (Rs)',
  ]
  const tableX = margin
  const headerHeightRow = 24
  const tableRowHeights = invoice.lines.map((line) => {
    const wrappedDescription = wrapText(line.item.Description, colWidths[1] - 8, font, 8.5)
    return Math.max(24, wrappedDescription.length * 10 + 8)
  })
  const tableHeight = headerHeightRow + tableRowHeights.reduce((sum, height) => sum + height, 0)

  const summaryRows = [
    ['Quantity', String(invoice.quantity)],
    ['Total Taxable', formatMoney(invoice.taxableValue)],
    ['CGST 9%', formatMoney(invoice.cgst)],
    ['SGST 9%', formatMoney(invoice.sgst)],
    ['Taxable After GST', formatMoney(invoice.taxableAfterGst)],
    ['Non-Taxable Amount', formatMoney(invoice.nonTaxableValue)],
    ['TOTAL', formatMoney(invoice.total)],
  ]
  const summaryWidth = 280
  const summaryRowHeight = 20
  const summaryHeight = summaryRows.length * summaryRowHeight + 18
  const summaryX = pageWidth - margin - summaryWidth
  const declarationX = margin
  const declarationWidth = contentWidth - summaryWidth - 18
  const declarationText = 'DECLARATION: We hereby declare that this invoice actual price and goods details are true and correct.'
  const amountWords = `Amount In Words: ${numberToIndianWords(invoice.total)}`
  const declarationTextHeight = wrapText(declarationText, declarationWidth - 20, font, 9.5).length * 13
  const amountWordsHeight = wrapText(amountWords, declarationWidth - 20, fontBold, 9.5).length * 13
  const invoiceFacts = [
    `Total Number Of Items: ${invoice.lines.length}`,
    `Total Bags: ${invoice.lines.reduce((sum, line) => sum + line.bags, 0)}`,
    `Vehicle: ${invoice.vehicleNumber}`,
    `Buyer GSTIN: ${invoice.buyer.GSTIN}`,
  ]
  const factsHeight = invoiceFacts.length * 12
  const declarationBlockHeight = Math.max(
    summaryHeight,
    18 + declarationTextHeight + 10 + amountWordsHeight + 12 + factsHeight + 10,
  )
  const footerHeight = 80
  const footerLeftWidth = 340
  const footerRightWidth = contentWidth - footerLeftWidth - 16
  const requiredContentHeight =
    24 + // top margin area before title
    24 + // title spacing
    headerHeight +
    12 +
    addressHeight +
    14 +
    tableHeight +
    12 +
    declarationBlockHeight +
    14 +
    footerHeight +
    18
  const pageHeight = Math.max(595.28, requiredContentHeight)
  const page = pdf.addPage([pageWidth, pageHeight])
  let cursorY = pageHeight - 24

  drawCenteredText(page, 'TAX INVOICE', pageWidth / 2, cursorY, fontBold, 18, black)
  cursorY -= 24

  drawBox(page, margin, cursorY - headerHeight, headerLeftWidth, headerHeight)
  drawBox(page, margin + headerLeftWidth + 16, cursorY - headerHeight, headerRightWidth, headerHeight)
  drawWrappedText(page, companyLines[0], {
    x: margin + 12,
    y: cursorY - 22,
    maxWidth: headerLeftWidth - 24,
    font: fontBold,
    size: 15,
    lineHeight: 16,
    color: red,
  })
  drawWrappedText(page, companyLines.slice(1).join('\n'), {
    x: margin + 12,
    y: cursorY - 42,
    maxWidth: headerLeftWidth - 24,
    font,
    size: 10,
    lineHeight: lineGap,
    color: black,
  })

  metaRows.forEach(([label, value], index) => {
    const y = cursorY - 20 - index * 19
    drawText(page, `${label}:`, margin + headerLeftWidth + 28, y, fontBold, 10, black)
    drawText(page, value, margin + headerLeftWidth + 128, y, font, 10, black)
  })

  cursorY -= headerHeight + 12

  drawBox(page, margin, cursorY - addressHeight, toBoxWidth, addressHeight)
  drawText(page, 'TO:', margin + 10, cursorY - 18, fontBold, 11, black)

  drawWrappedLineList(page, buyerLines, {
    x: margin + 10,
    y: cursorY - 34,
    width: toBoxWidth - 20,
    font,
    fontBold,
    lineHeight: lineGap,
    color: black,
  })
  if (hasDistinctShipTo) {
    drawBox(page, margin + buyerWidth + 18, cursorY - addressHeight, shipBoxWidth, addressHeight)
    drawText(page, 'SHIP TO:', margin + buyerWidth + 28, cursorY - 18, fontBold, 11, black)
    drawWrappedLineList(page, shipLines, {
      x: margin + buyerWidth + 28,
      y: cursorY - 34,
      width: shipBoxWidth - 20,
      font,
      fontBold,
      lineHeight: lineGap,
      color: black,
    })
  }

  cursorY -= addressHeight + 14

  drawTableRow(page, headers, {
    x: tableX,
    y: cursorY - headerHeightRow,
    widths: colWidths,
    height: headerHeightRow,
    font: fontBold,
    size: 8.5,
    color: black,
    fillColor: rgb(0.96, 0.93, 0.9),
    numericColumns: [2, 3, 4, 5, 6, 7, 8, 9],
  })
  cursorY -= headerHeightRow

  invoice.lines.forEach((line, index) => {
    const rowValues = [
      String(index + 1),
      `${line.item.Description} (${line.bags} bags)`,
      '7010',
      String(line.quantity),
      formatMoney(line.grossRate),
      formatMoney(line.amount),
      formatMoney(line.nonTaxableRate),
      formatMoney(line.nonTaxableValue),
      formatMoney(line.taxableRate),
      formatMoney(line.taxableValue),
    ]
    const rowHeight = tableRowHeights[index]

    drawTableRow(page, rowValues, {
      x: tableX,
      y: cursorY - rowHeight,
      widths: colWidths,
      height: rowHeight,
      font,
      size: 8.5,
      color: black,
      numericColumns: [2, 3, 4, 5, 6, 7, 8, 9],
    })
    cursorY -= rowHeight
  })

  cursorY -= 12
  const lowerBlockTop = cursorY

  drawBox(page, summaryX, lowerBlockTop - summaryHeight, summaryWidth, summaryHeight)
  drawText(page, 'SUMMARY', summaryX + 10, lowerBlockTop - 16, fontBold, 11, black)
  summaryRows.forEach(([label, value], index) => {
    const y = lowerBlockTop - 34 - index * summaryRowHeight
    const labelFont = label === 'TOTAL' ? fontBold : font
    drawText(page, label, summaryX + 10, y, labelFont, 10, black)
    drawText(page, value, summaryX + 170, y, labelFont, 10, black)
  })

  drawBox(page, declarationX, lowerBlockTop - declarationBlockHeight, declarationWidth, declarationBlockHeight)
  drawText(page, 'DECLARATION', declarationX + 10, lowerBlockTop - 16, fontBold, 11, black)
  drawWrappedText(page, declarationText, {
    x: declarationX + 10,
    y: lowerBlockTop - 36,
    maxWidth: declarationWidth - 20,
    font,
    size: 9.5,
    lineHeight: 13,
    color: black,
  })
  drawWrappedText(page, amountWords, {
    x: declarationX + 10,
    y: lowerBlockTop - 36 - declarationTextHeight - 10,
    maxWidth: declarationWidth - 20,
    font: fontBold,
    size: 9.5,
    lineHeight: 13,
    color: black,
  })
  invoiceFacts.forEach((fact, index) => {
    drawText(
      page,
      fact,
      declarationX + 10,
      lowerBlockTop - 36 - declarationTextHeight - 10 - amountWordsHeight - 12 - index * 12,
      font,
      9,
      black,
    )
  })

  cursorY = lowerBlockTop - declarationBlockHeight - 14

  drawBox(page, margin, cursorY - footerHeight, footerLeftWidth, footerHeight)
  drawBox(page, margin + footerLeftWidth + 16, cursorY - footerHeight, footerRightWidth, footerHeight)

  drawText(page, 'BANK DETAILS', margin + 10, cursorY - 16, fontBold, 11, black)
  ;[
    'BANK NAME: KOTAK MAHINDRA',
    'BRANCH: KATRAJ, PUNE',
    'ACCOUNT NO.: 5949555673',
    'IFSC CODE: KKBK0001802',
  ].forEach((line, index) => {
    drawText(page, line, margin + 10, cursorY - 30 - index * 13, font, 9.5, black)
  })

  drawText(page, 'For YASH BOTTLE', margin + footerLeftWidth + 28, cursorY - 22, fontBold, 11, black)
  drawText(page, 'Authorized Signatory', margin + footerLeftWidth + 28, cursorY - 64, font, 10, black)

  const bytes = await pdf.save()
  await fs.writeFile(outputPath, bytes)
}

function drawText(page, text, x, y, font, size, color) {
  page.drawText(String(text || ''), { x, y, font, size, color })
}

function drawBox(page, x, y, width, height) {
  page.drawRectangle({
    x,
    y,
    width,
    height,
    borderWidth: 1,
    borderColor: rgb(0.08, 0.08, 0.08),
  })
}

function drawCenteredText(page, text, centerX, y, font, size, color) {
  const width = font.widthOfTextAtSize(text, size)
  drawText(page, text, centerX - width / 2, y, font, size, color)
}

function wrapText(text, maxWidth, font, size) {
  const source = String(text || '').trim()
  if (!source) {
    return ['']
  }

  const manualLines = source.split('\n')
  const lines = []

  manualLines.forEach((manualLine) => {
    const words = manualLine.split(/\s+/)
    let current = ''

    words.forEach((word) => {
      const next = current ? `${current} ${word}` : word
      const width = font.widthOfTextAtSize(next, size)
      if (width <= maxWidth) {
        current = next
      } else {
        if (current) {
          lines.push(current)
        }
        current = word
      }
    })

    if (current) {
      lines.push(current)
    }
  })

  return lines.length ? lines : ['']
}

function drawWrappedText(page, text, options) {
  const lines = wrapText(text, options.maxWidth, options.font, options.size)
  lines.forEach((line, index) => {
    drawText(
      page,
      line,
      options.x,
      options.y - index * options.lineHeight,
      options.font,
      options.size,
      options.color,
    )
  })
  return lines.length * options.lineHeight
}

function drawWrappedLineList(page, lines, options) {
  let currentY = options.y
  lines.forEach((line, index) => {
    const activeFont = index === 0 ? options.fontBold : options.font
    const activeSize = index === 0 ? 11 : 10
    const consumed = drawWrappedText(page, line, {
      x: options.x,
      y: currentY,
      maxWidth: options.width,
      font: activeFont,
      size: activeSize,
      lineHeight: options.lineHeight,
      color: options.color,
    })
    currentY -= consumed
  })
}

function drawTableRow(page, values, options) {
  let cursorX = options.x
  values.forEach((value, index) => {
    const width = options.widths[index]
    const isNumericColumn = options.numericColumns?.includes(index)
    const isEmphasisCell = options.emphasisColumns?.includes(index)
    page.drawRectangle({
      x: cursorX,
      y: options.y,
      width,
      height: options.height,
      borderWidth: 1,
      borderColor: options.color,
      color: isEmphasisCell ? rgb(0.95, 0.88, 0.82) : options.fillColor,
      opacity: options.fillColor ? 1 : undefined,
    })

    const wrapped = wrapText(value, width - 8, options.font, options.size)
    const lineHeight = 10
    const textBlockHeight = wrapped.length * lineHeight
    const startY = options.y + options.height - 10 - Math.max(0, (options.height - textBlockHeight - 6) / 2)

    wrapped.forEach((line, lineIndex) => {
      const lineWidth = options.font.widthOfTextAtSize(line, options.size)
      const textX = isNumericColumn ? cursorX + width - lineWidth - 4 : cursorX + 4
      drawText(page, line, textX, startY - lineIndex * lineHeight, options.font, options.size, options.color)
    })
    cursorX += width
  })
}

function formatDate(dateString) {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat('en-GB').format(date)
}

function formatMoney(value) {
  return Number(value).toFixed(2)
}

function roundCurrency(value) {
  return Math.round((value + Number.EPSILON) * 100) / 100
}

function sanitizeLine(value) {
  return String(value || '').replace(/\s+/g, ' ').trim()
}

function numberToIndianWords(value) {
  const rounded = Math.round(Number(value || 0) * 100) / 100
  const rupees = Math.floor(rounded)
  const paise = Math.round((rounded - rupees) * 100)
  const rupeeWords = `${convertIndianIntegerToWords(rupees)} Rupees`
  if (!paise) {
    return `${rupeeWords} Only`
  }
  return `${rupeeWords} and ${convertIndianIntegerToWords(paise)} Paise Only`
}

function convertIndianIntegerToWords(number) {
  if (number === 0) {
    return 'Zero'
  }

  const ones = [
    '',
    'One',
    'Two',
    'Three',
    'Four',
    'Five',
    'Six',
    'Seven',
    'Eight',
    'Nine',
    'Ten',
    'Eleven',
    'Twelve',
    'Thirteen',
    'Fourteen',
    'Fifteen',
    'Sixteen',
    'Seventeen',
    'Eighteen',
    'Nineteen',
  ]
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']

  function belowThousand(n) {
    let result = ''
    if (n >= 100) {
      result += `${ones[Math.floor(n / 100)]} Hundred`
      n %= 100
      if (n) {
        result += ' '
      }
    }
    if (n >= 20) {
      result += tens[Math.floor(n / 10)]
      if (n % 10) {
        result += ` ${ones[n % 10]}`
      }
    } else if (n > 0) {
      result += ones[n]
    }
    return result.trim()
  }

  const parts = []
  const crore = Math.floor(number / 10000000)
  const lakh = Math.floor((number % 10000000) / 100000)
  const thousand = Math.floor((number % 100000) / 1000)
  const remainder = number % 1000

  if (crore) {
    parts.push(`${belowThousand(crore)} Crore`)
  }
  if (lakh) {
    parts.push(`${belowThousand(lakh)} Lakh`)
  }
  if (thousand) {
    parts.push(`${belowThousand(thousand)} Thousand`)
  }
  if (remainder) {
    parts.push(belowThousand(remainder))
  }

  return parts.join(' ').trim()
}
