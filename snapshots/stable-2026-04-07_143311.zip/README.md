# Invoice Web App

This folder now contains a working invoice web app built around your existing files:

- `Buyers_Master.csv`
- `Items_Master.csv`
- `Invoice Temp.xlsx`

## What it does

- Loads buyers from `Buyers_Master.csv`
- Loads items from `Items_Master.csv`
- Lets you select buyer and item from dropdowns
- Lets you enter vehicle number, bags, and invoice date
- Auto-calculates quantity using `Bottles_Per_Bag`
- Generates:
  - a filled Excel invoice based on `Invoice Temp.xlsx`
  - a PDF invoice from the same invoice data
- Saves generated files into `generated/`

## Run locally

Install dependencies:

```powershell
npm install
```

Run frontend and backend together:

```powershell
npm run dev
```

Open:

```text
http://localhost:5173
```

## Production run

Build the frontend:

```powershell
npm run build
```

Start the backend:

```powershell
npm start
```

Open:

```text
http://localhost:5000
```

The backend will serve the built frontend from `dist/` when it exists.

## Generated files

Generated files are written to:

```text
generated/
```

Example files already verified:

- `generated/001-2026-27.xlsx`
- `generated/001-2026-27.pdf`

## Current invoice logic

- quantity = `bags * Bottles_Per_Bag`
- taxable rate = `Gross_Rate - Non_Taxable_Rate`
- CGST = `9%` of taxable value
- SGST = `9%` of taxable value
- total = `non-taxable value + taxable value + CGST + SGST`

## Notes

- Invoice numbering is generated from existing `.xlsx` files in `generated/`
- PDF is generated from the same invoice data as the Excel file
- If you later want multi-item invoices, invoice history, login, or database storage, this project is a solid base for that
